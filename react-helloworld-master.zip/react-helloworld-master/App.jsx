import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>simon, helloworld!!!</div>
    );
  }
}

export default App;
